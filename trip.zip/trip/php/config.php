<?php
$database_connection = mysqli_connect("localhost", "root", "", "trip_data");
?>